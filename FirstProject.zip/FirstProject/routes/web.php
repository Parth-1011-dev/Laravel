
<?php

use Illuminate\Support\Facades\Route;

Route::get('/', fn() => '<h1>Laravel Route Parameters</h1>');

Route::get('/post/{id}', fn(string $id) => "Post ID: " . e($id));

Route::get('/optional-post/{id?}', fn(?string $id = null) =>
    $id ? "Post ID: " . e($id) : "No ID Found"
);

Route::get('/post/{id}/comment/{commentId}', fn(string $id, string $commentId) =>
    "Post ID: " . e($id) . "<br>Comment ID: " . e($commentId)
);

Route::get('/numeric/{id}', fn(string $id) => e($id))
    ->whereNumber('id');

Route::get('/alpha/{id}', fn(string $id) => e($id))
    ->whereAlpha('id');

Route::get('/alphanumeric/{id}', fn(string $id) => e($id))
    ->whereAlphaNumeric('id');

Route::get('/category/{type}', fn(string $type) => e($type))
    ->whereIn('type', ['movie', 'song', 'painting']);

Route::get('/custom-number/{id}', fn(string $id) => e($id))
    ->where('id', '[0-9]+');

Route::get('/custom-alpha/{id}', fn(string $id) => e($id))
    ->where('id', '[a-zA-Z]+');

Route::get('/constrained-post/{id}/comment/{commentId}',
    fn(string $id, string $commentId) =>
        "Post ID: " . e($id) . "<br>Comment ID: " . e($commentId)
)->whereNumber('id')->whereAlpha('commentId');

Route::get('/tag/{id}', fn(string $id) => e($id))
    ->where('id', '@[0-9]+');

Route::get('/three-digits/{id}', fn(string $id) => e($id))
    ->where('id', '[0-9]{3}');
