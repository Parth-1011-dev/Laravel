<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UserController extends Controller
{
    public function showProfile($id)
    {
        return view('user.profile', ['userId' => $id]);
    }

    public function redirectToProfile()
    {
        return redirect()->route('user.profile', ['id' => 5]);
    }

    public function orders()
    {
        return view('user.orders');
    }

    public function settings()
    {
        return view('user.settings');
    }
}