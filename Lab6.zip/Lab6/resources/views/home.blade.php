<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
</head>
<body>
    <h1>Welcome to the Home Page</h1>
    <nav>
        <ul>
            <li><a href="{{ route('home') }}">Home</a></li>
            <li><a href="{{ route('about') }}">About Us</a></li>
            <li><a href="{{ route('user.profile', ['id' => 10]) }}">User Profile (ID: 10)</a></li>
            <li><a href="{{ route('admin.dashboard') }}">Admin Dashboard</a></li>
            <li><a href="{{ route('admin.users') }}">Manage Users</a></li>
            <li><a href="{{ route('blade.demo') }}">View Blade Template Demo</a></li>
        </ul>
    </nav>
</body>
</html>