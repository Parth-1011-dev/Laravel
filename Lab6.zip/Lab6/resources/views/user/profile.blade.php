<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Profile</title>
</head>
<body>
    <h1>User Profile</h1>
    <p>User ID: {{ $userId }}</p>
    <p><a href="{{ route('home') }}">Back to Home</a></p>
</body>
</html>