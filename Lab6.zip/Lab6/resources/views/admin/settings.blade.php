<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin - Settings</title>
</head>
<body>
    <h1>Admin Settings</h1>
    <p><a href="{{ route('admin.dashboard') }}">Back to Dashboard</a></p>
</body>
</html>