<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
</head>
<body>
    <h1>Admin Dashboard</h1>
    <ul>
        <li><a href="{{ route('admin.users') }}">Manage Users</a></li>
        <li><a href="{{ route('admin.settings') }}">Settings</a></li>
        <li><a href="{{ route('home') }}">Back to Main Site</a></li>
    </ul>
</body>
</html>