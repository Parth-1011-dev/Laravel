<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin - Users</title>
</head>
<body>
    <h1>Manage Users</h1>
    <p><a href="{{ route('admin.dashboard') }}">Back to Dashboard</a></p>
</body>
</html>