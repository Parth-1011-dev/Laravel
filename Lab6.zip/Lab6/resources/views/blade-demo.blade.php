<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laravel Blade Template Demo</title>
</head>
<body>

    <h1>1. Displaying Variables</h1>
    <p>Hello, {{ $user }}</p>

    <h1>2. Rendering HTML Output</h1>
    {!! $demoHtml !!}

    <hr>

    <h1>3. Blade Conditionals (@@if / @@unless)</h1>
    
    @if ($user == 'Yahoo Baba')
        <p>Welcome back, Admin {{ $user }}!</p>
    @else
        <p>Welcome, Guest!</p>
    @endif

    @unless ($user == 'Guest')
        <p>You are logged in.</p>
    @endunless

    <hr>

    <h1>4. Loop Directives (Forelse)</h1>

    <ul>
        @forelse ($fruits as $fruit)
            <li>{{ $loop->iteration }}. {{ $fruit }}</li>
        @empty
            <li>No fruits available.</li>
        @endforelse
    </ul>

    <hr>

    <h1>5. Raw PHP Block</h1>

    @php
        $status = 'Active';
        $count = 10;
    @endphp

    <p>Status: <strong>{{ $status }}</strong> |
       Count: <strong>{{ $count }}</strong></p>

    <br>

    <a href="{{ route('home') }}">Back to Home</a>

</body>
</html>
