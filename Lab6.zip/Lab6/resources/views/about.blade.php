<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>About Us</title>
</head>
<body>
    <h1>About Us Page</h1>
    <p><a href="{{ route('home') }}">Back to Home</a></p>
</body>
</html>