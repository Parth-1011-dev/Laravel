<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laravel Blade Template - I</title>
</head>
<body>

    <!-- 1. Displaying Variables & Escaping Data -->
    <h1>Hello, {{ $user }}</h1>

    <!-- 2. Rendering Unescaped HTML Output -->
    {!! $demoHtml !!}

    <hr>

    <!-- 3. Blade Conditional Directives (@if, @elseif, @else) -->
    @if($user == 'Yahoo Baba')
        <p>Welcome back, Admin {{ $user }}!</p>
    @elseif($user == 'Guest')
        <p>Welcome, Guest user!</p>
    @else
        <p>User not recognized.</p>
    @endif

    <!-- 4. @unless Directive (inverse of @if) -->
    @unless($user == 'Guest')
        <p>You are logged in as a registered user.</p>
    @endunless

    <hr>

    <!-- 5. Blade Loop Directives (@foreach, @empty) -->
    <h3>Fruit List:</h3>
    <ul>
        @forelse($fruits as $fruit)
            <li>{{ $loop->iteration }}. {{ $fruit }}</li>
        @empty
            <li>No fruits available in the list.</li>
        @endforelse
    </ul>

    <hr>

    <!-- 6. Raw PHP Block in Blade (@php) -->
    @php
        $status = "Active";
        $count = 10;
    @endphp

    <p>Account Status: <strong>{{ $status }}</strong></p>
    <p>Total Items: <strong>{{ $count }}</strong></p>

    <!-- 7. Blade Comments (Will not appear in HTML source) -->
    {{-- This is a Blade comment and will be hidden from the browser output --}}

</body>
</html>