<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laravel Blade Template Demo</title>
</head>
<body>

    <h1>1. Displaying Variables</h1>
    <p>Hello, <?php echo e($user); ?></p>

    <h1>2. Rendering HTML Output</h1>
    <?php echo $demoHtml; ?>


    <hr>

    <h1>3. Blade Conditionals (@if / @unless)</h1>
    
    <?php if($user == 'Yahoo Baba'): ?>
        <p>Welcome back, Admin <?php echo e($user); ?>!</p>
    <?php else: ?>
        <p>Welcome, Guest!</p>
    <?php endif; ?>

    <?php if (! ($user == 'Guest')): ?>
        <p>You are logged in.</p>
    <?php endif; ?>

    <hr>

    <h1>4. Loop Directives (Forelse)</h1>

    <ul>
        <?php $__empty_1 = true; $__currentLoopData = $fruits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fruit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <li><?php echo e($loop->iteration); ?>. <?php echo e($fruit); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <li>No fruits available.</li>
        <?php endif; ?>
    </ul>

    <hr>

    <h1>5. Raw PHP Block</h1>

    <?php
        $status = 'Active';
        $count = 10;
    ?>

    <p>Status: <strong><?php echo e($status); ?></strong> |
       Count: <strong><?php echo e($count); ?></strong></p>

    <br>

    <a href="<?php echo e(route('home')); ?>">Back to Home</a>

</body>
</html>
<?php /**PATH E:\laragon\www\Lab6\resources\views/blade-demo.blade.php ENDPATH**/ ?>