<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\AdminController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

// --------------------------------------------------
// Lesson 1: Basic Named Routes & Controllers
// --------------------------------------------------
Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/about-us', [HomeController::class, 'about'])->name('about');
Route::get('/user/{id}/profile', [UserController::class, 'showProfile'])->name('user.profile');

// Admin Route Group
Route::prefix('admin')->name('admin.')->group(function () {
    Route::get('/dashboard', [AdminController::class, 'dashboard'])->name('dashboard');
    Route::get('/users', [AdminController::class, 'users'])->name('users');
    Route::get('/settings', [AdminController::class, 'settings'])->name('settings');
});

// --------------------------------------------------
// Lesson 2: Blade Template Demo Route
// --------------------------------------------------
Route::get('/blade-demo', function () {
    $name = "Yahoo Baba";
    $fruits = ['Apple', 'Banana', 'Orange', 'Grapes'];
    $htmlString = "<h3>Welcome to Laravel Blade Tutorial</h3>";

    return view('blade-demo', [
        'user' => $name,
        'fruits' => $fruits,
        'demoHtml' => $htmlString
    ]);
})->name('blade.demo');