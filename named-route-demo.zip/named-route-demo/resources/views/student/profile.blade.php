
@extends('layout')

@section('title', 'Student Profile')

@section('content')
    <h1>Student Profile</h1>

    <p>Student ID: {{ $id }}</p>
    <p>Route name: student.profile</p>
@endsection
