
@extends('layout')

@section('title', 'Student Dashboard')

@section('content')
    <h1>Student Dashboard</h1>
    <p>Welcome to the student section.</p>

    <a href="{{ route('student.profile', ['id' => 101]) }}">
        View Student Profile
    </a>
@endsection
