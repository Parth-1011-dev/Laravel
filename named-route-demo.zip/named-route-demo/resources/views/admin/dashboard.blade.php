
@extends('layout')

@section('title', 'Admin Dashboard')

@section('content')
    <h1>Admin Dashboard</h1>
    <p>This page belongs to the admin route group.</p>

    <a href="{{ route('admin.users') }}">Manage Users</a>
@endsection
