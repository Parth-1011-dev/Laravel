
@extends('layout')

@section('title', 'Admin Users')

@section('content')
    <h1>Admin Users</h1>
    <p>This URL uses the admin prefix.</p>
    <p>URL: /admin/users</p>
    <p>Route name: admin.users</p>
@endsection
