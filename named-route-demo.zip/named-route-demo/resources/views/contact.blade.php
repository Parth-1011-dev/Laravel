
@extends('layout')

@section('title', 'Contact')

@section('content')
    <h1>Contact Us</h1>
    <p>Email: example@example.com</p>
    <p>Route name: <strong>contact</strong></p>
@endsection
