
@extends('layout')

@section('title', 'About')

@section('content')
    <h1>About Us</h1>
    <p>This page demonstrates a named route.</p>
    <p>Route name: <strong>about</strong></p>
@endsection
