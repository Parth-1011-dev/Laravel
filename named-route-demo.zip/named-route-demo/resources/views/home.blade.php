
@extends('layout')

@section('title', 'Home')

@section('content')
    <h1>Welcome to Laravel Named Routes</h1>
    <p>This is the home page.</p>

    <ul>
        <li><a href="{{ route('about') }}">About Us</a></li>
        <li><a href="{{ route('contact') }}">Contact Us</a></li>
        <li><a href="{{ route('admin.users') }}">View Admin Users</a></li>
        <li>
            <a href="{{ route('student.profile', ['id' => 101]) }}">
                View Student Profile
            </a>
        </li>
    </ul>
@endsection
