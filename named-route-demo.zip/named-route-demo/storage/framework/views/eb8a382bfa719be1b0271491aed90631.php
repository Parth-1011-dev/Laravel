


<?php $__env->startSection('title', 'Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Admin Dashboard</h1>
    <p>This page belongs to the admin route group.</p>

    <a href="<?php echo e(route('admin.users')); ?>">Manage Users</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laragon\www\named-route-demo\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>