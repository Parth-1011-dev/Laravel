


<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Welcome to Laravel Named Routes</h1>
    <p>This is the home page.</p>

    <ul>
        <li><a href="<?php echo e(route('about')); ?>">About Us</a></li>
        <li><a href="<?php echo e(route('contact')); ?>">Contact Us</a></li>
        <li><a href="<?php echo e(route('admin.users')); ?>">View Admin Users</a></li>
        <li>
            <a href="<?php echo e(route('student.profile', ['id' => 101])); ?>">
                View Student Profile
            </a>
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laragon\www\named-route-demo\resources\views/home.blade.php ENDPATH**/ ?>