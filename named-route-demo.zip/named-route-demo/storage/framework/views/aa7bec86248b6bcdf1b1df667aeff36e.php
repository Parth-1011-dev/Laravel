


<?php $__env->startSection('title', 'About'); ?>

<?php $__env->startSection('content'); ?>
    <h1>About Us</h1>
    <p>This page demonstrates a named route.</p>
    <p>Route name: <strong>about</strong></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laragon\www\named-route-demo\resources\views/about.blade.php ENDPATH**/ ?>