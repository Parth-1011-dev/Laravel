
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?> - Laravel Routing</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 40px;
            background: #f4f6f9;
            color: #222;
        }

        nav {
            background: #202938;
            padding: 18px;
            border-radius: 8px;
        }

        nav a {
            color: white;
            text-decoration: none;
            margin-right: 20px;
        }

        main {
            background: white;
            padding: 25px;
            margin-top: 20px;
            border-radius: 8px;
        }

        a { color: #2563eb; }
    </style>
</head>
<body>

    <nav>
        <a href="<?php echo e(route('home')); ?>">Home</a>
        <a href="<?php echo e(route('about')); ?>">About</a>
        <a href="<?php echo e(route('contact')); ?>">Contact</a>
        <a href="<?php echo e(route('admin.dashboard')); ?>">Admin</a>
        <a href="<?php echo e(route('student.dashboard')); ?>">Student</a>
    </nav>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

</body>
</html>
<?php /**PATH E:\laragon\www\named-route-demo\resources\views/layout.blade.php ENDPATH**/ ?>