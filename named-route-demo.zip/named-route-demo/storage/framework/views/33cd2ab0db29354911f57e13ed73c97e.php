


<?php $__env->startSection('title', 'Admin Users'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Admin Users</h1>
    <p>This URL uses the admin prefix.</p>
    <p>URL: /admin/users</p>
    <p>Route name: admin.users</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laragon\www\named-route-demo\resources\views/admin/users.blade.php ENDPATH**/ ?>