


<?php $__env->startSection('title', 'Contact'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Contact Us</h1>
    <p>Email: example@example.com</p>
    <p>Route name: <strong>contact</strong></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laragon\www\named-route-demo\resources\views/contact.blade.php ENDPATH**/ ?>