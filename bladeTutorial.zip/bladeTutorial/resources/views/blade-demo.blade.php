
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laravel Blade Tutorial</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 30px; background: #f4f6f9; }
        h1 { background: #f05252; color: white; padding: 18px; border-radius: 8px; }
        section { background: white; padding: 18px; margin: 15px 0; border-radius: 8px; }
        li { margin: 8px 0; }
    </style>
</head>
<body>

<h1>Laravel Blade Template Tutorial</h1>

<section>
    <h2>1. Blade Syntax</h2>
    @php
        $name = "Parth";
        $course = "Laravel 10";
    @endphp
    <p>Name: {{ $name }}</p>
    <p>Course: {{ $course }}</p>
</section>

<section>
    <h2>2. Conditional Statements</h2>
    @php
        $marks = 75;
        $day = 2;
        $message = "";
        $username = "Parth";
        $items = [];
    @endphp

    @if($marks >= 70)
        <p>Result: Distinction</p>
    @elseif($marks >= 50)
        <p>Result: Pass</p>
    @else
        <p>Result: Fail</p>
    @endif

    @switch($day)
        @case(1)
            <p>Monday</p>
            @break
        @case(2)
            <p>Tuesday</p>
            @break
        @default
            <p>Other day</p>
    @endswitch

    @isset($username)
        <p>Username: {{ $username }}</p>
    @endisset

    @empty($items)
        <p>The item list is empty.</p>
    @endempty
</section>

<section>
    <h2>3. Looping Statements</h2>

    <h3>For Loop</h3>
    @for($i = 1; $i <= 5; $i++)
        <span>{{ $i }} </span>
    @endfor

    <h3>Foreach Loop</h3>
    @php
        $students = ['Parth', 'Rahul', 'Amit', 'Neha'];
    @endphp

    <ul>
        @foreach($students as $student)
            <li>{{ $student }}</li>
        @endforeach
    </ul>

    <h3>While Loop</h3>
    @php $count = 1; @endphp
    @while($count <= 3)
        <p>Count: {{ $count }}</p>
        @php $count++; @endphp
    @endwhile
</section>

<section>
    <h2>4. Blade Loop Variables</h2>

    <ul>
        @foreach($students as $student)
            <li>
                {{ $loop->iteration }}. {{ $student }}

                @if($loop->last)
                    - Last Student
                @endif
            </li>
        @endforeach
    </ul>
</section>

<section>
    <h2>5. PHP vs Blade Output</h2>
    @php
        $html = '<strong>Blade Escaped Output</strong>';
    @endphp

    <p>Escaped output: {{ $html }}</p>
    <p>Raw HTML output: {!! $html !!}</p>
</section>

</body>
</html>
