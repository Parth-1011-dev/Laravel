<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
</head>
<body>
    <h1>About My Laravel Project</h1>
    <p>This is my first Blade template.</p>
</body>
</html><?php /**PATH D:\bladeTutorial\resources\views/about.blade.php ENDPATH**/ ?>