
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laravel Blade Tutorial</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 30px; background: #f4f6f9; }
        h1 { background: #f05252; color: white; padding: 18px; border-radius: 8px; }
        section { background: white; padding: 18px; margin: 15px 0; border-radius: 8px; }
        li { margin: 8px 0; }
    </style>
</head>
<body>

<h1>Laravel Blade Template Tutorial</h1>

<section>
    <h2>1. Blade Syntax</h2>
    <?php
        $name = "Parth";
        $course = "Laravel 10";
    ?>
    <p>Name: <?php echo e($name); ?></p>
    <p>Course: <?php echo e($course); ?></p>
</section>

<section>
    <h2>2. Conditional Statements</h2>
    <?php
        $marks = 75;
        $day = 2;
        $message = "";
        $username = "Parth";
        $items = [];
    ?>

    <?php if($marks >= 70): ?>
        <p>Result: Distinction</p>
    <?php elseif($marks >= 50): ?>
        <p>Result: Pass</p>
    <?php else: ?>
        <p>Result: Fail</p>
    <?php endif; ?>

    <?php switch($day):
        case (1): ?>
            <p>Monday</p>
            <?php break; ?>
        <?php case (2): ?>
            <p>Tuesday</p>
            <?php break; ?>
        <?php default: ?>
            <p>Other day</p>
    <?php endswitch; ?>

    <?php if(isset($username)): ?>
        <p>Username: <?php echo e($username); ?></p>
    <?php endif; ?>

    <?php if(empty($items)): ?>
        <p>The item list is empty.</p>
    <?php endif; ?>
</section>

<section>
    <h2>3. Looping Statements</h2>

    <h3>For Loop</h3>
    <?php for($i = 1; $i <= 5; $i++): ?>
        <span><?php echo e($i); ?> </span>
    <?php endfor; ?>

    <h3>Foreach Loop</h3>
    <?php
        $students = ['Parth', 'Rahul', 'Amit', 'Neha'];
    ?>

    <ul>
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($student); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <h3>While Loop</h3>
    <?php $count = 1; ?>
    <?php while($count <= 3): ?>
        <p>Count: <?php echo e($count); ?></p>
        <?php $count++; ?>
    <?php endwhile; ?>
</section>

<section>
    <h2>4. Blade Loop Variables</h2>

    <ul>
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <?php echo e($loop->iteration); ?>. <?php echo e($student); ?>


                <?php if($loop->last): ?>
                    - Last Student
                <?php endif; ?>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</section>

<section>
    <h2>5. PHP vs Blade Output</h2>
    <?php
        $html = '<strong>Blade Escaped Output</strong>';
    ?>

    <p>Escaped output: <?php echo e($html); ?></p>
    <p>Raw HTML output: <?php echo $html; ?></p>
</section>

</body>
</html>
<?php /**PATH D:\bladeTutorial\resources\views/blade-demo.blade.php ENDPATH**/ ?>