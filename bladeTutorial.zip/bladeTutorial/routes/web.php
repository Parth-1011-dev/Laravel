<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/home', function () {
    return 'Welcome to my Laravel Project!';
});

Route::get('/about', function () {
    return view('about');
});

Route::get('/blade-demo', function () {
    return view('blade-demo');
});

Route::get('/blade-demo', function () {
    return view('blade-demo');
});
